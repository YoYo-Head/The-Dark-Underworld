extends ProgressBar

var parent

func _ready() -> void:
	await get_tree().physics_frame
	
	parent = get_parent()
	
	print(parent.name)

	max_value = parent.MaxHealth
	value = parent.currentHealth

func _process(_delta: float) -> void:
	
	if parent == null:
		return

	max_value = parent.MaxHealth
	value = parent.currentHealth
	"""
	if parent.currentHealth < parent.maxhealth:
		visible = true
	else:
		visible = false
	"""	
	$healthLabel.text = str(int(value))
		
	
